package com.springboot.SIMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimsApplicationTests {

	@Test
	void contextLoads() {
	}

}
