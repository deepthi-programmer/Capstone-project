package com.example.sims.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstone.inventory_system.InventoryItem;
import com.capstone.inventory_system.InventoryItemRepository;

@Service
public class InventoryItemService {

    @Autowired
    private InventoryItemRepository repository;

    @Autowired
    private NotificationService notificationService;

    public List<InventoryItem> getAllItems() {
        return repository.findAll();
    }

    public Optional<InventoryItem> getItemById(Long id) {
        return repository.findById(id);
    }

    public InventoryItem addItem(InventoryItem item) {
        InventoryItem savedItem = repository.save(item);
        notificationService.sendNotification("Item added: " + item.getName());
        return savedItem;
    }

    public InventoryItem updateItem(Long id, InventoryItem item) {
        item.setId(id);
        InventoryItem updatedItem = repository.save(item);
        notificationService.sendNotification("Item updated: " + item.getName());
        return updatedItem;
    }

    public void deleteItem(Long id) {
        repository.deleteById(id);
        notificationService.sendNotification("Item deleted with ID: " + id);
    }
}
