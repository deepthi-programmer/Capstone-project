package com.example.sims.controller;

import com.example.sims.service.InventoryItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/analytics")
public class AnalyticsController {

    @Autowired
    private InventoryItemService service;

    @GetMapping
    public Map<String, Object> getInventorySummary() {
        Map<String, Object> summary = new HashMap<>();
        summary.put("totalItems", service.getAllItems().size());
        summary.put("totalValue", service.getAllItems().stream().mapToDouble(item -> item.getPrice() * item.getQuantity()).sum());
        return summary;
    }
}
