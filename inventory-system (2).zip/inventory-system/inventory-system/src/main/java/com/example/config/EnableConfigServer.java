package com.example.config;

public @interface EnableConfigServer {

}
