package com.example.eureka;

public @interface EnableEurekaServer {

}
