package com.example.sims.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.inventory_system.InventoryItem;
import com.capstone.inventory_system.InventoryItemRepository;

@RestController
@RequestMapping("/api/inventory")
public class InventoryService {

    @Autowired
    private InventoryItemRepository inventoryRepository;

    @GetMapping("/{id}")
    public ResponseEntity<InventoryItem> getInventoryById(@PathVariable Long id) {
        Optional<InventoryItem> inventory = inventoryRepository.findById(id);
        if (inventory.isPresent()) {
            return ResponseEntity.ok(inventory.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<InventoryItem> addInventory(@RequestBody InventoryItem inventory) {
        InventoryItem savedInventory = inventoryRepository.save(inventory);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedInventory);
    }

    @PutMapping("/{id}")
    public ResponseEntity<InventoryItem> updateInventory(@PathVariable Long id, @RequestBody InventoryItem inventoryDetails) {
        Optional<InventoryItem> inventory = inventoryRepository.findById(id);
        if (inventory.isPresent()) {
            InventoryItem updatedInventory = inventory.get();
            updatedInventory.setName(inventoryDetails.getName());
            updatedInventory.setQuantity(inventoryDetails.getQuantity());
            inventoryRepository.save(updatedInventory);
            return ResponseEntity.ok(updatedInventory);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInventory(@PathVariable Long id) {
        inventoryRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
